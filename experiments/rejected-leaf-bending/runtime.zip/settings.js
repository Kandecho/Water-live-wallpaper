/* Water HD artistic controls. Reload after editing; no runtime build step. Apache-2.0. */
(function(root){
  'use strict';
  const settings={
    render:{maxFPS:60,maxDPR:2,gridRows:96,maxColumns:600},
    scene:{leafCount:14,leafSize:.55,leafScale:[.4,.5]},
    waves:{maxSources:12,lifetime:6,speed:.85,height:.018,frequency:19,width:14,rise:9,decay:.68,
      ambientInterval:[2.4,4.5],ambientStrength:.13,landingStrength:.75},
    drift:{velocityX:[-.006,.006],velocityY:[-.044,-.036],spin:[-.09,.09],fallSpeed:.15,settleTime:.24,flow:[.012,.006]},
    breeze:{delay:3,period:30,duration:13,direction:.35,directionSpread:.3,
      driftSpeed:.045,responseTime:.65,waveHeight:.010,waveNumber:5.2,waveSpeed:.65,
      manualRise:1.2,manualDuration:8,airSpin:.5,airSpinFadeHeight:.18},
    bend:{segments:8,hinge:.10,rest:.05,wind:.23,waveGain:1.4,max:.32,responseTime:.38},
    water:{refraction:.10,normalScale:.85,diffuse:.13,sheen:.15,sheenPower:42},
    light:{direction:[-.38,.54,.751],ambient:[.61,.65,.69],keyColor:[1.04,1.,.91],keyStrength:.53,canopyStrength:.48,
      // Offline artistic projection. UV offsets use this same light direction.
      canopy:{resolution:512,dark:[18,58],chroma:[10,38],blur:7,
        levels:[.10,.64],projectionHeight:.055,scale:1.02}},
    leaf:{ridge:.32,curl:.22,normalTilt:.9,shear:.20,squash:.24,turn:.22,bob:.45,
      contactShadow:.07,airShadow:.17,
      // Original atlas leaf roots and main-vein axes, in image coordinates.
      origins:[[.5,.53],[.51,.68],[.34,.64],[.52,.69],[.34,.34],[.51,.72],[.52,.69],[.34,.60]],
      axes:[[0,-1],[-.12,-.99],[.2,-.98],[0,-1],[.5,-.866],[0,-1],[0,-1],[.42,-.908]]},
    contact:{depth:.0052,directionalLight:.12,waveGain:14,waveLimit:.16,
      restTilt:.045,liftRange:[.7,1],
      // 0: petiole wet / tip lifted; 1: petiole lifted; 2: side lifted.
      // Local UV axes are relative to the main vein, shared with offline maps.
      poses:[[1,0],[-1,0],[0,1]]},
    input:{spacing:.085,cadence:.075,clickStrength:1,dragStrength:.55},
    // One definition drives defaults, panel grouping and keyboard shortcuts.
    features:[
      {key:'lighting',label:'光照',group:'光影',code:'KeyC',enabled:true},
      {key:'canopy',label:'树荫',group:'光影',code:'KeyS',enabled:true},
      {key:'motion',label:'轻摆',group:'水面',code:'KeyB',enabled:true},
      {key:'breeze',label:'轻风',group:'风',code:'KeyG',enabled:true},
      {key:'bending',label:'弯曲',group:'叶片',code:'KeyF',enabled:true},
      {key:'contact',label:'叶缘接触',group:'水面',code:'KeyT',enabled:true},
      {key:'leaves',label:'叶子',group:'画面',code:'KeyL',enabled:true}
    ]
  };
  if(typeof module!=='undefined'&&module.exports)module.exports=settings;else root.WaterSettings=settings;
})(typeof globalThis!=='undefined'?globalThis:this);
